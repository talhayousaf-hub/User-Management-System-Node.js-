// User.js
class User {
    // Step 2: Define fields
    constructor(email, password, fullName, dateOfBirth, contacts, securityQuestion, securityAnswer) {
        // Step 3: Validate inputs
        if (!this.isValidEmail(email)) throw new Error('Invalid email format');
        if (contacts.length > 2) throw new Error('Max 2 contact numbers allowed');
        if (!this.isValidPassword(password)) throw new Error('Password does not meet security requirements');

        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.dateOfBirth = new Date(dateOfBirth);
        this.contacts = contacts;
        this.securityQuestion = securityQuestion;
        this.securityAnswer = securityAnswer;
    }

    // Email validation
    isValidEmail(email) {
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        return emailRegex.test(email);
    }

    // Password validation (example: should be at least 6 characters)
    isValidPassword(password) {
        return password.length >= 6;
    }

    // Step 4: Getters and Setters
    getEmail() { return this.email; }
    setEmail(email) {
        if (this.isValidEmail(email)) this.email = email;
        else throw new Error('Invalid email format');
    }

    getPassword() { return this.password; }
    setPassword(password) {
        if (this.isValidPassword(password)) this.password = password;
        else throw new Error('Password does not meet security requirements');
    }

    getFullName() { return this.fullName; }
    setFullName(name) { this.fullName = name; }

    getContacts() { return this.contacts; }
    setContacts(contacts) {
        if (contacts.length <= 2) this.contacts = contacts;
        else throw new Error('Max 2 contact numbers allowed');
    }

    // Step 5: Add methods
    summary() {
        return `${this.fullName} (${this.email})`;
    }

    details() {
        return {
            fullName: this.fullName,
            email: this.email,
            contacts: this.contacts,
            dateOfBirth: this.dateOfBirth,
            securityQuestion: this.securityQuestion,
        };
    }

    calculateAge() {
        const ageDifMs = Date.now() - this.dateOfBirth.getTime();
        const ageDate = new Date(ageDifMs);
        return Math.abs(ageDate.getUTCFullYear() - 1970); // Calculate age
    }
}

// Step 6: Export the User class
module.exports = User;