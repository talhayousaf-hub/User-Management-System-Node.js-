// app.js
const User = require('./User'); // Import the User class

try {
    // Step 7: Create 2-3 user objects
    const user1 = new User(
        'user1@example.com', 'password123', 'John Doe', '1990-05-15', ['1234567890'], 'What is your pet’s name?', 'Fluffy'
    );
    const user2 = new User(
        'user2@example.com', 'mypassword', 'Jane Doe', '1995-08-20', ['0987654321'], 'What is your mother’s maiden name?', 'Smith'
    );

    // Step 7: Use methods on objects and print results
    console.log(user1.summary()); // John Doe (user1@example.com)
    console.log(user1.details()); // User details except password
    console.log(`Age: ${user1.calculateAge()} years`);

    console.log(user2.summary()); // Jane Doe (user2@example.com)
    console.log(user2.details());
    console.log(`Age: ${user2.calculateAge()} years`);

} catch (error) {
    console.error('Error:', error.message); // Handle errors
} finally {
    console.log('Execution complete'); // Cleanup code
}